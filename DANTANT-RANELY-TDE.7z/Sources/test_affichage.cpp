#include "../Headers/affichage.h"

int main() {

	unsigned char couleurGrille[3] = { 0,0,255 };
	affichage Grille(couleurGrille,10,10); // Test simple de la grille d'affichage

	return 0;
}