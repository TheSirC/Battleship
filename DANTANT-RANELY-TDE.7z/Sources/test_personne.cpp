using namespace std;
#include <iostream>
#include "../Headers/JoueurHumain.h"
#include "../Headers/JoueurOrdi.h"
#include "../Headers/Personne.h"

void main()
{
	int rep = 0;
	do
	{
		JoueurOrdi comp;
		comp.ChoixCible(10, 10);
		int x = comp.getCibleX(); 
		int y = comp.getCibleY();
		cout << "Cible X: " << x << endl;
		cout << "Cible Y: " << y << endl;
		cout << "Retirer? [0/1]" << endl;
		cin >> rep;
	} while (rep==0);   ///OK
	
	int rep = 0;
	JoueurHumain comp("Claudi",6);
	do
	{
	
	comp.ChoixCible(7, 8);
	int x = comp.getCibleX();
	int y = comp.getCibleY();
	cout << "Cible X: " << x << endl;
	cout << "Cible Y: " << y << endl;
	cout << "Retirer? [0/1]" << endl;
	cin >> rep;
	} while (rep==0);   //OK

	Personne J1("Joueur1", 6);
	cout << "nb bateaux"<<J1.getNbBateaux()<<endl;
	cout << "nom" << J1.getNom() << endl;
	cout << "flotte" << J1.getFlotte << endl;
	J1.setNom("Joueur2");
	J1.ajouterBateau(1,1,1,4,1);
	J1.setNbBateaux(8);
	cout << "modification" << endl;
	cout << "nb bateaux" << J1.getNbBateaux() << endl;
	cout << "nom" << J1.getNom() << endl;
	cout << "flotte" << J1.getFlotte << endl;


}