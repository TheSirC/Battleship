#include "../Headers/optionMenu.h"

// Definition des methodes de la classe OptionMenu
OptionMenu::OptionMenu(const string &nom, const string &description): nom_(nom), description_(description)
{
}
