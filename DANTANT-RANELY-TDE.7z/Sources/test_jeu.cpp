#include "../Headers/jeu.h"

int main()
{
		Jeu *BatailleNavale = new Jeu("Humain",4);

}