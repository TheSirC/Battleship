
#include "../Headers/Bateau.h"
#include <vector>



Bateau::Bateau(int orientation, int taille)
{
	tailleBat_ = taille;
	orientation_ = orientation;
}